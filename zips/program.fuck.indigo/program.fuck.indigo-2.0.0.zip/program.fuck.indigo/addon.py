import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
 
line1 = "Preventing Device Hijacking"
line2 = "Some Developers Tried to Hijack Your Device"
line3 = "This Has Stopped Them"
 
xbmcgui.Dialog().ok(addonname, line1, line2, line3)
